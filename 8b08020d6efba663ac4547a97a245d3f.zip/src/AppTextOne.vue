<template>
  <div class="card">
    <h3>Это компонент ОДИН</h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis, vel.</p>
    <div class="form-control">
      <input type="text">
    </div>
  </div>
</template>

<script>
  export default {

  }
</script>

<style scoped>

</style>