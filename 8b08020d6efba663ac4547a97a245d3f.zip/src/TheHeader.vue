<template>
  <h2>{{title}}</h2>
  <hr />
  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid, aperiam architecto et in itaque natus optio possimus similique suscipit voluptatibus.</p>
</template>


<script>
export default {
  data() {
    return {
      title: 'The Header from Data'
    }
  }
}
</script>